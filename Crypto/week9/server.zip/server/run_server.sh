#!/bin/bash

export FLASK_APP=www
export FLASK_ENV=development
flask run

